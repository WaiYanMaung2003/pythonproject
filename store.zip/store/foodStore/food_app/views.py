from django.shortcuts import render, redirect
from food_app.models import *
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required, permission_required
from django.contrib.auth.models import User
from django.contrib.auth.hashers import make_password
from django.db.models import Q
from django.core.paginator import Paginator

# Create your views here.

def home(request):
    home = Post.objects.all()
    return render(request,'home.html',{'home':home})


def product(request):
    category = request.GET.get('category')
    
    if category:
        page_obj = Post.objects.filter(category_id=category)
    
    else:
        posts = Post.objects.all().order_by('-created_at')
        paginator = Paginator(posts, 3)
        page_number = request.GET.get('page')
        page_obj = paginator.get_page(page_number)
    return render(request,'product.html',{'product':page_obj})

@permission_required('food_app.add_post', login_url='login')
def addpost(request):
    if request.method == "GET":
        category=Category.objects.all()
        return render(request,'addpost.html',{'category':category})
    if request.method == "POST":
        Post.objects.create(
            title = request.POST.get('title'),
            content = request.POST.get('content'),
            
            image = request.FILES.get('image'),
            category_id = request.POST.get('category'),
            author_id = request.user.id
        )
        messages.success(request, "Post Created Success!")
        return redirect('/product/')
    
def postdetail(request, p_id):
    if request.method == "GET":
        
        post = Post.objects.get(id=p_id)
        return render(request, 'postdetail.html', {'p': post,})
    if request.method == "POST":
        
        return redirect('/login')
        
    
@permission_required('food_app.change_post', login_url='login')
def postupdate(request,p_id):
    if request.method == "GET":
        post = Post.objects.get(id=p_id)
        category = Category.objects.all()
        return render(request, 'postupdate.html', {'p':post,'category':category})
    if request.method == "POST":
        post = Post.objects.get(id=p_id)
        post.title = request.POST.get('title')
        post.content = request.POST.get('content')
        if request.FILES.get('image'):
            post.image.delete()
            post.image = request.FILES.get('image')
        post.category_id = request.POST.get('category')
        post.save()
        messages.success(request, "Post Updated Success!")
        return redirect('/product/')
    
@permission_required('food_app.delete_post', login_url='login')
def postdelete(request,p_id):
    post = Post.objects.get(id=p_id)
    post.image.delete()
    post.delete()
    messages.success(request, "Post Deleted Success!")
    return redirect('/product')

def mylogin(request):
    if request.method == "GET":
        return render(request, 'login.html')
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username=username, password=password)
        if user:
            login(request, user)
            messages.success(request, "Login Success!")
            return redirect('/home')
        else:
            messages.error(request, "Username Or Password is Incorrect!")
            return redirect('/login')
        
def mylogut(request):
    logout(request)
    return redirect('/home')
        
def myregister(request):
    if request.method == "GET":
        return render(request,'Register.html')
    if request.method == "POST":
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        repassword = request.POST.get('repassword')
        if password == repassword:
            if User.objects.filter(username=username):
                messages.error(request, 'username already exists')
                return redirect('/register')
            if User.objects.filter(email=email):
                messages.error(request, 'email already exists')
                return redirect('/register')
            user = User.objects.create(
                username = username,
                email = email,
                password = make_password(password)
            )
            login(request, user)
            return redirect('/home')
        else:
            messages.error(request, 'Password is not same!')
            return redirect('/register')
        
