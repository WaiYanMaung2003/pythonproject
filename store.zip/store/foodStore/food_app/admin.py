from django.contrib import admin
from food_app.models import Category, Post, UserDetail

# Register your models here.

class CategoryAdmin(admin.ModelAdmin):
    list_display = ['id','name','created_at']

class PostAdmin(admin.ModelAdmin):
    list_display = ['id','title','content','image','category','author','created_at']



admin.site.register(Category, CategoryAdmin)
admin.site.register(Post, PostAdmin)
admin.site.register(UserDetail)
