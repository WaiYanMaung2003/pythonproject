from django.db import models
from datetime import datetime
from django.contrib.auth.models import User
import uuid

class UserDetail(models.Model):
    id = models.UUIDField(primary_key=True,default=uuid.uuid4)
    image = models.ImageField(default=None)
    dob = models.DateField(default=None)
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(default=datetime.now)

class Category(models.Model):
    id = models.UUIDField(primary_key=True,default=uuid.uuid4)
    name = models.CharField(max_length=100)
    description = models.TextField(default=None)
    created_at = models.DateTimeField(default=datetime.now)

    def __str__(self):
        return self.name

class Post(models.Model):
    id = models.UUIDField(primary_key=True,default=uuid.uuid4)
    title = models.CharField(max_length=100)
    content = models.TextField(default=None)
    image = models.ImageField(default=None)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(default=datetime.now)

    def __str__(self):
        return self.title
